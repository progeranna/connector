use std::sync::Arc;

use sqlx::PgPool;

use crate::{
    config::{DetectorSettings, HealthScoreSettings},
    runtime::RuntimeModeHandle,
    runtime_supervisor::IngestionSupervisor,
    storage::RedisCache,
    telemetry::InternalCounters,
};

#[cfg(test)]
use crate::domain::{AnomalyEvent, TradeEvent};

#[derive(Clone)]
pub struct AppState {
    pub pg_pool: PgPool,
    pub redis_cache: RedisCache,
    pub detector_settings: DetectorSettings,
    pub health_settings: HealthScoreSettings,
    pub runtime_mode: RuntimeModeHandle,
    pub supervisor: Arc<IngestionSupervisor>,
    pub counters: InternalCounters,
    #[cfg(test)]
    pub test_recent_anomalies: Option<Vec<AnomalyEvent>>,
    #[cfg(test)]
    pub test_recent_trades: Option<Vec<TradeEvent>>,
}
