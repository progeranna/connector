use axum::{Router, routing::get};

use super::{contract, handlers};

pub fn router() -> Router<super::AppState> {
    Router::new()
        .route(contract::HEALTH, get(handlers::health))
        .route(
            contract::RUNTIME_MODE,
            get(handlers::runtime_mode).post(handlers::switch_runtime_mode),
        )
        .route(contract::METRICS, get(handlers::metrics))
        .route(contract::PIPELINE_HEALTH, get(handlers::pipeline_health))
        .route(
            contract::DASHBOARD_SUMMARY,
            get(handlers::dashboard_summary),
        )
        .route(contract::SYMBOLS, get(handlers::symbols))
        .route(contract::MARKET_STATE, get(handlers::market_state))
        .route(contract::MARKET_HEALTH, get(handlers::market_health))
        .route(contract::MARKET_TIMELINE, get(handlers::market_timeline))
        .route(contract::ANOMALIES, get(handlers::anomalies))
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use axum::{
        body::Body,
        http::{Request, StatusCode, header},
        response::Response,
    };
    use sqlx::postgres::{PgConnectOptions, PgPoolOptions};
    use tower::ServiceExt;

    use super::router;
    use crate::{
        api::AppState,
        config::{
            BinanceSettings, DetectorSettings, HealthScoreSettings, HealthStatusThresholds,
            IngestionMode, IngestionSettings, SeverityPenaltySettings,
        },
        runtime::RuntimeModeHandle,
        runtime::RuntimeModeSnapshot,
        runtime_supervisor::IngestionSupervisor,
        storage::RedisCache,
        telemetry::InternalCounters,
    };
    use chrono::TimeZone;
    use rust_decimal::Decimal;

    #[tokio::test]
    async fn health_route_returns_ok() {
        let response = get("/health", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn metrics_route_returns_ok() {
        let response = get("/metrics", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn runtime_mode_route_returns_ok() {
        let response = get("/runtime/mode", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn runtime_mode_route_returns_expected_fields() {
        let response = get("/runtime/mode", unavailable_state()).await;

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body: serde_json::Value = serde_json::from_slice(&body).unwrap();

        assert_eq!(body["mode"], "replay");
        assert_eq!(body["mode_label"], "Replay Demo");
        assert_eq!(body["status"], "running");
        assert_eq!(body["symbols"], serde_json::json!(["BTCUSDT"]));
        assert_eq!(body["switching_supported"], false);
        assert_eq!(body["source"], "config");
        assert!(body["last_started_at"].is_string());
        assert!(body["last_switched_at"].is_null());
        assert!(body["last_error"].is_null());
    }

    #[tokio::test]
    async fn runtime_mode_route_reports_enabled_operator_gate() {
        let response = get("/runtime/mode", unavailable_state_with_switching(true)).await;
        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body: serde_json::Value = serde_json::from_slice(&body).unwrap();

        assert_eq!(body["switching_supported"], true);
    }

    #[tokio::test]
    async fn runtime_mode_switch_route_rejects_invalid_mode() {
        let state = unavailable_state_with_switching(true);

        let response = post(
            "/runtime/mode",
            serde_json::json!({
                "mode": "invalid",
                "reset_state": false,
                "reset_storage": false
            }),
            state,
        )
        .await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn runtime_mode_switch_route_returns_forbidden_when_disabled() {
        let response = post(
            "/runtime/mode",
            serde_json::json!({
                "mode": "live",
                "symbols": ["BTCUSDT"]
            }),
            unavailable_state(),
        )
        .await;

        assert_eq!(response.status(), StatusCode::FORBIDDEN);

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body: serde_json::Value = serde_json::from_slice(&body).unwrap();

        assert_eq!(body["error"], "forbidden");
        assert_eq!(body["message"], "runtime mode switching is disabled");
    }

    #[tokio::test]
    async fn disabled_runtime_mode_route_rejects_explicit_destructive_flags() {
        let response = post(
            "/runtime/mode",
            serde_json::json!({
                "mode": "replay",
                "reset_state": true,
                "reset_storage": true
            }),
            unavailable_state(),
        )
        .await;

        assert_eq!(response.status(), StatusCode::FORBIDDEN);
    }

    #[tokio::test]
    async fn runtime_mode_switch_route_preserves_existing_behavior_when_enabled() {
        let state = unavailable_state_with_switching(true);

        let response = post(
            "/runtime/mode",
            serde_json::json!({
                "mode": "live",
                "symbols": ["BTCUSDT"]
            }),
            state,
        )
        .await;

        assert_eq!(response.status(), StatusCode::OK);

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body: serde_json::Value = serde_json::from_slice(&body).unwrap();

        assert_eq!(body["mode"], "live");
        assert_eq!(body["symbols"], serde_json::json!(["BTCUSDT"]));
        assert_eq!(body["switching_supported"], true);
    }

    #[tokio::test]
    async fn metrics_route_returns_prometheus_metrics() {
        let counters = InternalCounters::default();
        counters.increment_parse_errors();
        counters.increment_binance_quote_events();

        let response = get(
            "/metrics",
            AppState {
                pg_pool: unused_test_pool(),
                redis_cache: RedisCache::unavailable(),
                detector_settings: detector_settings(),
                health_settings: health_settings(),
                runtime_mode: runtime_mode_handle(),
                supervisor: test_supervisor(false),
                counters,
                test_recent_anomalies: None,
                test_recent_trades: None,
            },
        )
        .await;

        assert_eq!(
            response.headers().get(header::CONTENT_TYPE).unwrap(),
            "text/plain; version=0.0.4; charset=utf-8"
        );

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body = String::from_utf8(body.to_vec()).unwrap();

        assert!(body.contains("signalguard_parse_errors_total"));
        assert!(body.contains(
            "signalguard_events_processed_total{source=\"binance\",event_type=\"quote\"} 1"
        ));
    }

    #[tokio::test]
    async fn pipeline_health_route_returns_ok() {
        let response = get("/pipeline/health", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn pipeline_health_route_returns_expected_fields() {
        let counters = InternalCounters::default();
        counters.increment_parse_errors();
        let response = get(
            "/pipeline/health",
            AppState {
                pg_pool: unused_test_pool(),
                redis_cache: RedisCache::unavailable(),
                detector_settings: detector_settings(),
                health_settings: health_settings(),
                runtime_mode: runtime_mode_handle(),
                supervisor: test_supervisor(false),
                counters,
                test_recent_anomalies: None,
                test_recent_trades: None,
            },
        )
        .await;

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body = String::from_utf8(body.to_vec()).unwrap();

        assert!(body.contains("\"status\""));
        assert!(body.contains("\"parse_errors\":1"));
        assert!(body.contains("\"reconnect_attempts\""));
        assert!(body.contains("\"storage_errors\""));
        assert!(body.contains("\"cache_errors\""));
    }

    #[tokio::test]
    async fn dashboard_summary_route_returns_ok() {
        let response = get("/dashboard/summary", dashboard_state()).await;

        assert_eq!(response.status(), StatusCode::OK);

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body: serde_json::Value = serde_json::from_slice(&body).unwrap();

        assert!(body.get("service").is_some());
        assert!(body.get("pipeline").is_some());
        assert!(body["symbols"].as_array().is_some());
        assert!(body["recent_anomalies"].as_array().is_some());
    }

    #[tokio::test]
    async fn dashboard_summary_route_accepts_demo_mode() {
        let response = get("/dashboard/summary?mode=demo", dashboard_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn dashboard_summary_demo_mode_does_not_require_live_storage() {
        let response = get("/dashboard/summary?mode=demo", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn dashboard_summary_route_accepts_live_mode() {
        let response = get("/dashboard/summary?mode=live", dashboard_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn dashboard_summary_route_rejects_invalid_mode() {
        let response = get("/dashboard/summary?mode=prod", dashboard_state()).await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn symbols_route_reports_unavailable_cache() {
        let response = get("/symbols", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    }

    #[tokio::test]
    async fn market_state_route_reports_unavailable_cache() {
        let response = get("/market/BTCUSDT/state", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    }

    #[tokio::test]
    async fn market_health_route_reports_unavailable_cache() {
        let response = get("/market/BTCUSDT/health", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    }

    #[tokio::test]
    async fn market_timeline_route_rejects_invalid_symbol() {
        let response = get("/market/BTC-USDT/timeline", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn market_timeline_route_accepts_demo_mode() {
        let response = get("/market/BTCUSDT/timeline?mode=demo", timeline_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn market_timeline_demo_mode_does_not_require_live_storage() {
        let response = get("/market/BTCUSDT/timeline?mode=demo", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn market_timeline_demo_mode_returns_eth_history() {
        let response = get("/market/ETHUSDT/timeline?mode=demo", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body: serde_json::Value = serde_json::from_slice(&body).unwrap();

        assert_eq!(body["symbol"], "ETHUSDT");
        assert!(body["points"].as_array().unwrap().len() >= 2);
    }

    #[tokio::test]
    async fn market_timeline_route_accepts_live_mode() {
        let response = get("/market/BTCUSDT/timeline?mode=live", timeline_state()).await;

        assert_eq!(response.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn market_timeline_route_returns_empty_points_for_demo_market_without_history() {
        let response = get("/market/ADAUSDT/timeline?mode=demo", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::OK);

        let body = axum::body::to_bytes(response.into_body(), usize::MAX)
            .await
            .unwrap();
        let body: serde_json::Value = serde_json::from_slice(&body).unwrap();

        assert_eq!(body["symbol"], "ADAUSDT");
        assert_eq!(body["points"], serde_json::json!([]));
    }

    #[tokio::test]
    async fn market_timeline_route_rejects_invalid_mode() {
        let response = get("/market/BTCUSDT/timeline?mode=prod", timeline_state()).await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn market_health_route_rejects_invalid_symbol() {
        let response = get("/market/BTC-USDT/health", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn anomalies_route_rejects_invalid_limit() {
        let response = get("/anomalies?limit=invalid", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn anomalies_route_rejects_zero_limit() {
        let response = get("/anomalies?limit=0", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn anomalies_route_rejects_limit_above_maximum() {
        let response = get("/anomalies?limit=501", unavailable_state()).await;

        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn extractor_rejection_probe_matrix_records_actual_http_behavior() {
        let probes = [
            (
                "dashboard invalid mode",
                get("/dashboard/summary?mode=prod", dashboard_state()).await,
                StatusCode::BAD_REQUEST,
                "text/plain; charset=utf-8",
                false,
            ),
            (
                "timeline invalid mode",
                get("/market/BTCUSDT/timeline?mode=prod", timeline_state()).await,
                StatusCode::BAD_REQUEST,
                "text/plain; charset=utf-8",
                false,
            ),
            (
                "timeline invalid symbol",
                get("/market/BTC-USDT/timeline?mode=demo", timeline_state()).await,
                StatusCode::BAD_REQUEST,
                "application/json",
                true,
            ),
            (
                "anomalies invalid limit",
                get("/anomalies?limit=wat", unavailable_state()).await,
                StatusCode::BAD_REQUEST,
                "application/json",
                true,
            ),
            (
                "anomalies invalid symbol",
                get("/anomalies?symbol=BTC-USDT", unavailable_state()).await,
                StatusCode::BAD_REQUEST,
                "application/json",
                true,
            ),
            (
                "post malformed json",
                raw_post("/runtime/mode", Some("application/json"), "{").await,
                StatusCode::BAD_REQUEST,
                "text/plain; charset=utf-8",
                false,
            ),
            (
                "post wrong field type",
                raw_post("/runtime/mode", Some("application/json"), r#"{"mode":42}"#).await,
                StatusCode::UNPROCESSABLE_ENTITY,
                "text/plain; charset=utf-8",
                false,
            ),
            (
                "post missing mode",
                raw_post(
                    "/runtime/mode",
                    Some("application/json"),
                    r#"{"symbols":[]}"#,
                )
                .await,
                StatusCode::UNPROCESSABLE_ENTITY,
                "text/plain; charset=utf-8",
                false,
            ),
            (
                "post missing content type",
                raw_post("/runtime/mode", None, r#"{"mode":"live"}"#).await,
                StatusCode::UNSUPPORTED_MEDIA_TYPE,
                "text/plain; charset=utf-8",
                false,
            ),
            (
                "post wrong content type",
                raw_post("/runtime/mode", Some("text/plain"), r#"{"mode":"live"}"#).await,
                StatusCode::UNSUPPORTED_MEDIA_TYPE,
                "text/plain; charset=utf-8",
                false,
            ),
            (
                "post unsupported mode",
                post_with_switching(
                    "/runtime/mode",
                    serde_json::json!({"mode":"unsupported"}),
                    true,
                )
                .await,
                StatusCode::BAD_REQUEST,
                "application/json",
                true,
            ),
            (
                "post switching forbidden",
                post(
                    "/runtime/mode",
                    serde_json::json!({"mode":"live"}),
                    unavailable_state(),
                )
                .await,
                StatusCode::FORBIDDEN,
                "application/json",
                true,
            ),
        ];
        for (label, response, expected_status, expected_content_type, expect_json) in probes {
            let status = response.status();
            let content_type = response
                .headers()
                .get(header::CONTENT_TYPE)
                .and_then(|value| value.to_str().ok())
                .unwrap_or("<missing>")
                .to_owned();
            let body = String::from_utf8(
                axum::body::to_bytes(response.into_body(), usize::MAX)
                    .await
                    .unwrap()
                    .to_vec(),
            )
            .unwrap();
            println!("{label}: status={status} content_type={content_type} body={body}");
            assert_eq!(status, expected_status, "{label} status");
            assert_eq!(content_type, expected_content_type, "{label} content type");
            assert!(!body.is_empty());
            if expect_json {
                let body: serde_json::Value =
                    serde_json::from_str(&body).expect("handler errors are JSON");
                assert!(body["error"].is_string());
                assert!(body["message"].is_string());
            }
        }
    }

    async fn get(path: &str, state: AppState) -> Response {
        router()
            .with_state(state)
            .oneshot(Request::get(path).body(Body::empty()).unwrap())
            .await
            .unwrap()
    }

    async fn post(path: &str, body: serde_json::Value, state: AppState) -> Response {
        router()
            .with_state(state)
            .oneshot(
                Request::post(path)
                    .header(header::CONTENT_TYPE, "application/json")
                    .body(Body::from(body.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap()
    }

    async fn post_with_switching(
        path: &str,
        body: serde_json::Value,
        switching_supported: bool,
    ) -> Response {
        post(
            path,
            body,
            unavailable_state_with_switching(switching_supported),
        )
        .await
    }

    async fn raw_post(path: &str, content_type: Option<&str>, body: &str) -> Response {
        let mut request = Request::post(path);
        if let Some(content_type) = content_type {
            request = request.header(header::CONTENT_TYPE, content_type);
        }
        router()
            .with_state(unavailable_state())
            .oneshot(request.body(Body::from(body.to_owned())).unwrap())
            .await
            .unwrap()
    }

    fn unavailable_state() -> AppState {
        unavailable_state_with_switching(false)
    }

    fn unavailable_state_with_switching(switching_supported: bool) -> AppState {
        let supervisor = test_supervisor(switching_supported);
        AppState {
            pg_pool: unused_test_pool(),
            redis_cache: RedisCache::unavailable(),
            detector_settings: detector_settings(),
            health_settings: health_settings(),
            runtime_mode: supervisor.runtime_mode_handle(),
            supervisor,
            counters: InternalCounters::default(),
            test_recent_anomalies: None,
            test_recent_trades: None,
        }
    }

    fn dashboard_state() -> AppState {
        AppState {
            pg_pool: unused_test_pool(),
            redis_cache: RedisCache::in_memory(Vec::new()),
            detector_settings: detector_settings(),
            health_settings: health_settings(),
            runtime_mode: runtime_mode_handle(),
            supervisor: test_supervisor(false),
            counters: InternalCounters::default(),
            test_recent_anomalies: Some(Vec::new()),
            test_recent_trades: None,
        }
    }

    fn timeline_state() -> AppState {
        AppState {
            pg_pool: unused_test_pool(),
            redis_cache: RedisCache::in_memory(Vec::new()),
            detector_settings: detector_settings(),
            health_settings: health_settings(),
            runtime_mode: runtime_mode_handle(),
            supervisor: test_supervisor(false),
            counters: InternalCounters::default(),
            test_recent_anomalies: Some(Vec::new()),
            test_recent_trades: Some(vec![
                crate::domain::TradeEvent::new(
                    crate::domain::Symbol::new("BTCUSDT").unwrap(),
                    crate::domain::Exchange::Binance,
                    Some(1),
                    Decimal::new(100, 0),
                    Decimal::new(1, 0),
                    chrono::Utc.with_ymd_and_hms(2026, 7, 2, 12, 0, 0).unwrap(),
                    chrono::Utc.with_ymd_and_hms(2026, 7, 2, 12, 0, 1).unwrap(),
                )
                .unwrap(),
            ]),
        }
    }

    fn runtime_mode_snapshot() -> RuntimeModeSnapshot {
        RuntimeModeSnapshot::from_startup_config(
            IngestionMode::Replay,
            &[crate::domain::Symbol::new("BTCUSDT").unwrap()],
            chrono::Utc.with_ymd_and_hms(2026, 7, 2, 12, 0, 0).unwrap(),
            false,
        )
    }

    fn runtime_mode_handle() -> RuntimeModeHandle {
        RuntimeModeHandle::new(runtime_mode_snapshot())
    }

    fn test_supervisor(switching_supported: bool) -> Arc<IngestionSupervisor> {
        Arc::new(IngestionSupervisor::new(
            &IngestionSettings {
                mode: IngestionMode::Replay,
                symbols: vec![crate::domain::Symbol::new("BTCUSDT").unwrap()],
                replay_path: std::path::PathBuf::from("examples/replay/sample.jsonl"),
                replay_delay_ms: 0,
                replay_reset_state: true,
                replay_reset_storage: false,
                event_channel_capacity: 16,
            },
            &BinanceSettings {
                websocket_base_url: String::from("wss://stream.binance.com:9443"),
                reconnect_min_backoff_ms: 500,
                reconnect_max_backoff_ms: 5_000,
            },
            &detector_settings(),
            switching_supported,
            unused_test_pool(),
            RedisCache::in_memory(Vec::new()),
            InternalCounters::default(),
        ))
    }

    fn unused_test_pool() -> sqlx::PgPool {
        PgPoolOptions::new().max_connections(1).connect_lazy_with(
            PgConnectOptions::new()
                .host("/tmp/signalguard-rs-test-unused-postgres")
                .username("signalguard")
                .password("signalguard")
                .database("signalguard"),
        )
    }

    fn detector_settings() -> DetectorSettings {
        DetectorSettings {
            price_move_1m_pct_threshold: Decimal::new(25, 1),
            spread_spike_pct_threshold: Decimal::new(5, 1),
            stale_data_ms_threshold: 5_000,
            trade_burst_multiplier: Decimal::new(3, 0),
            trade_burst_min_warmup_windows: 5,
            quote_stuck_ms_threshold: 10_000,
            event_lag_spike_ms_threshold: 3_000,
            depth_sequence_gap_min_increment: 1,
        }
    }

    fn health_settings() -> HealthScoreSettings {
        HealthScoreSettings {
            base_score: 100,
            severity_penalties: SeverityPenaltySettings {
                info: 5,
                warning: 15,
                critical: 35,
            },
            stale_data_penalty: 25,
            recent_anomaly_window_secs: 300,
            status_thresholds: HealthStatusThresholds {
                healthy_min_score: 80,
                degraded_min_score: 50,
            },
        }
    }
}
